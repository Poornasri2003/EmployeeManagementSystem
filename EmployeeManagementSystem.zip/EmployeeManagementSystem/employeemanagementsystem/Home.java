package employeemanagementsystem;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
public class Home extends JFrame implements ActionListener{
    JButton view , add, update,remove;
    Home(){
       setLayout(null);
       setSize(1120,630);
       setLocation(250,100);
       setVisible(true);

       
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/add.png"));
        Image i2 = i1.getImage().getScaledInstance(1120, 630, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 1120, 630);
        add(image);

        JLabel heading=new JLabel("Employee management System");
        heading.setBounds(650,20,400,40);
        heading.setFont(new Font("serif",Font.BOLD,25));
        image.add(heading);

        add=new JButton("Add employee");
        add.setBounds(650,80,150,40);
        image.add(add);
        add.addActionListener(this);

        
         update=new JButton("update employee");
        update.setBounds(820,80,150,40);
        image.add(update);
               update.addActionListener(this);
        
         view=new JButton("View employee");
        view.setBounds(650,140,150,40);
        image.add(view);
        view.addActionListener(this);
        remove=new JButton("Remove employee");
        remove.setBounds(820,140,150,40);
        image.add(remove);
               remove.addActionListener(this);
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==add)
        {
           setVisible(false);
           new AddEmployee();
        }else if(ae.getSource()== view)
        {
          setVisible(false);
           new ViewEmployee();
           
        }else if(ae.getSource()== update){
         new UpdateEmployee("");
        }else{
         new RemoveEmployee();
        }

    }
    public static void main(String args[]){
       new Home();
    }

}