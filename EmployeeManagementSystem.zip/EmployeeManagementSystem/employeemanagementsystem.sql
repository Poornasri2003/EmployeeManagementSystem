-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2023 at 11:12 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `employeemanagementsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `name` varchar(20) DEFAULT NULL,
  `fname` varchar(20) DEFAULT NULL,
  `dob` varchar(30) DEFAULT NULL,
  `salary` varchar(10) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `phone` varchar(13) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `education` varchar(20) DEFAULT NULL,
  `designation` varchar(30) DEFAULT NULL,
  `aadhar` varchar(25) DEFAULT NULL,
  `empid` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`name`, `fname`, `dob`, `salary`, `address`, `phone`, `email`, `education`, `designation`, `aadhar`, `empid`) VALUES
('Santhiya', 'Periyasamy', '30/12/1999', '2,00,000', 'sendhur nagar karur', '7904248627', 'san@gmail.com', 'BSC', 'HR', '364578819202', '90912'),
('poornasri', 'Periyasamy', '25/11/2003', '3,00,000', '82,aathikkal thottam ,karur -639113', '9025812842', 'poornasrip2003@gmail.com', 'BE', 'General Manager', '364578819202', '202291'),
('Rajeswari', 'Palanisamy', '19/11/2003', '3,00,000', '65,ponnagar , 1st cross sangagiri salem-639006', '7604802397', 'rajeswarip19@gmail.com', 'BE', 'General manager', '897590872341', '930678');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('raje', 'raje19');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
